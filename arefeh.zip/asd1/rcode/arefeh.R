#1
if (!require("magick")) install.packages("magick")
library(magick)
image1 <- image_read("C:/Users/Sazegar/Desktop/asd1/image/arefehsameei.jpg")
image2 <- image_read("C:/Users/Sazegar/Desktop/asd1/image/arefeh2.jpg")
image3 <- image_read("C:/Users/Sazegar/Desktop/asd1/image/arefeh3.jpg")
image4 <- image_read("C:/Users/Sazegar/Desktop/asd1/image/arefeh4.jpg")
image1 <- image_scale(image1, "300x300")
image2 <- image_scale(image2, "300x300")
image3 <- image_scale(image3, "300x300")
image4 <- image_scale(image4, "300x300")
image2 <- image_rotate(image2, 90)
image1 <- image_annotate(image1, "Image 1", size = 20, color = "red", location = "+10+10")
image2 <- image_annotate(image2, "Image 2", size = 20, color = "blue", location = "+10+10")
image3 <- image_annotate(image3, "Image 3", size = 20, color = "green", location = "+10+10")
image4 <- image_annotate(image4, "Image 4", size = 20, color = "purple", location = "+10+10")
grid <- c(image1, image2, image3, image4)
final_image <- image_montage(grid, geometry = "300x300+10+10", tile = "2x2")
print(final_image)
Sys.setenv(MAGICK_HOME = "C:/Program Files/ImageMagick")
blob <- image_write(final_image, format = "png")
writeBin(blob, "C:/Users/Sazegar/Desktop/final_image.png")




#2
if (!require("readxl")) install.packages("readxl")
if (!require("igraph")) install.packages("igraph")
if (!require("ggraph")) install.packages("ggraph")
if (!require("tidyverse")) install.packages("tidyverse")
library(readxl)
library(igraph)
library(ggraph)
library(tidyverse)
file_path <- "C:/Users/Sazegar/Desktop/asd1//Book1.txt.xlsx"   
data <- read_excel(file_path)
y <- data.frame(data$first, data$second)
net <- graph.data.frame(y, directed=T)
V(net)
E(net)
V(net)$label <- V(net)$name
V(net)$degree <- degree(net)
hist(V(net)$degree,
     col = 'red',
     main = 'Histogram of Node Degree',
     ylab = 'Frequency',
     xlab = 'Degree of Vertices')

set.seed(222)

plot(net,
     vertex.color = rainbow(5),
     vertex.size = V(net)$degree*0.4,
     edge.arrow.size = 0.5,
     main = "Enhanced Network Graph",
     layout=layout.fruchterman.reingold)




#3
if (!require("tm")) install.packages("tm")
if (!require("wordcloud2")) install.packages("wordcloud2")
if (!require("magick")) install.packages("magick")

library("tm")
library("wordcloud2")
library("magick")
text <- readLines(file.choose())


text <- tolower(text) 
text <- gsub("[[:punct:]]", " ", text) 
text <- gsub("[[:digit:]]", " ", text) 
text <- gsub("\\s+", " ", text) 
stop_words <- c("and", "or", "the", "of","for","with")
text <- removeWords(text, stop_words)
corpus <- Corpus(VectorSource(text))
dtm <- TermDocumentMatrix(corpus)
matrix <- as.matrix(dtm)


word_freq <- sort(rowSums(matrix), decreasing = TRUE)
word_freq_df <- data.frame(word = names(word_freq), freq = word_freq)

wordcloud2(
  data = word_freq_df, 
  shape = "circle", 
  size = 1.5, 
  color = "random-light", 
  backgroundColor = "black" 
)
